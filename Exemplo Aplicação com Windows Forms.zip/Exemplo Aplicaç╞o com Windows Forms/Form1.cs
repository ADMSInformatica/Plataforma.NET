using System.Runtime.CompilerServices;

namespace Banco
{
    public partial class Form1 : Form
    {
        Conta conta = new Conta();

        public Form1()
        {
            InitializeComponent();
        }

        //Evento do Bot�o Sair
        private void Sair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Classe Conta
        class Conta
        {
            //Atributos
            public int numero;
            public string titular;
            public string CPF;
            public double saldo;

            //M�todos
            public void Depositar(double d)
            {
                this.saldo += d;
            }
            public void Sacar(double s)
            {
                this.saldo -= s;
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            //Conta conta = new Conta();

            conta.numero = 1;
            conta.titular = "ADMS";
            conta.CPF = "12345678900";
            conta.saldo = 1000;

            textBox1.Text = conta.numero.ToString();
            textBox2.Text = conta.titular;
            textBox3.Text = conta.CPF;
            textBox4.Text = conta.saldo.ToString();
        }

        private void depositar_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                MessageBox.Show("Informe o Valor");
            }
            else
            {
                double valor = Convert.ToDouble(textBox5.Text);
                conta.Depositar(valor);
                MessageBox.Show("Dep�sito Realizado");
                textBox4.Text = conta.saldo.ToString();
                textBox5.Text = "";
            }
        }

        private void sacar_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                MessageBox.Show("Informe o Valor");
            }
            else
            {
                double valor = Convert.ToDouble(textBox6.Text);
                conta.Sacar(valor);
                MessageBox.Show("Saque Realizado");
                textBox4.Text = conta.saldo.ToString();
                textBox6.Text = "";
            }
        }
    }
}
